# 應用說明 - v0.1.0

* [**Table of Contents**](toc.md)
* **應用說明**

## 應用說明

| | |
| :--- | :--- |
| *Official URL*:http://example.org/ImplementationGuide/fhir.example | *Version*:0.1.0 |
| Draft as of 2025-10-28 | *Computable Name*:ExampleIG |

![](assets/images/logo-re.png)

## 介紹

臺灣xx 實作指引（Taiwan Long Term Care Implementation Guide，簡稱 **TW xx IG**）採用 HL7® FHIR® 標準（Fast Healthcare Interoperability Resources）建置方法， 在 FHIR R4.0.1 標準基礎上，參考：

* [台灣核心實作指引 (TW Core Implementation Guide)v.0.3.2](https://twcore.mohw.gov.tw/ig/twcore/index.html)
* [美國長期照顧實作指引 (eLTSS IG), STU2](https://www.fhir.org/guides/astp/bhp/index.html)
* [台灣長期照顧實作指引 (Taiwan Long-Term Care Implementation Guide)v0.4.0](https://ltc-ig.fhir.tw/)
* [美國核心實作指引 (US Core Implementation Guide)](https://build.fhir.org/ig/HL7/US-Core/en/index.html)

進一步定義適用於臺灣健康照護資料交換需求的 Resources、欄位、基數、資料型態、代碼綁定及查詢參數等。

TW xx IG 的實作方式有兩種：

1. **僅支援 Profiles**：系統僅支援 TW xx Profiles 以呈現健康照護資料。
1. **支援 Profiles + RESTful 互動**：系統支援 TW xx Profiles 及 RESTful API 互動。

-------

## 背景

鑒於衛生福利部全民健康保險急性後期整合照護計畫及電子病歷資料交換之需求， 本版本以 **FHIR R4.0.1** 為基礎，繼承自 **Taiwan xx Profiles/ValueSet** 與 **TW Core Profiles/ValueSet**， 以最大程度滿足電子病歷資料交換的相容性，同時參考其他國家長期照顧 IG 與衛福部電子病歷規範。

TW xx IG 將持續更新，各版本附有版本異動說明。
 所有經進一步定義的 Resource 或 Profile 稱為 Profiles，並依 **FMM 等級** 標記成熟度。

| | |
| :--- | :--- |
| DRAFT 0 | 草稿 |
| FMM 1 | 基本完成，可實作 |
| FMM 2 | 經測試，有三套系統互通資料 |
| FMM 3 | 經工作小組審查與修改 |
| FMM 4 | 正式出版並應用於多個專案 |
| FMM 5 | 維持兩個正式出版週期穩定 |
| Normative | 已被認定為穩定 |

-------

## 如何閱讀這個實作指引 (IG)

TW xx IG 網站主要架構如下：

* [應用說明](index.md):TW xx IG 介紹及背景說明
* [規範文件](regulation.md)：TW xx IG 能力聲明、所有 Profiles 與查詢參數及操作定義、專門術語及 Extensions。 
* [能力聲明](capability.md)：應用 TW xx IG 於建置業務目的使用的 FHIR Server 時，該 FHIR Server 必須及建議應該支援的操作功能。
* [查詢參數及操作定義](parameter.md)：查詢 FHIR Server 的 Profiles時，針對各 Profiles可使用的查詢參數及操作定義。
* [邏輯模型 (Logical Models)](logic.md)：TW xx IG 的所有邏輯模型（Logical Models），各邏輯模型會定義相應情境下使用的所有資料欄位。為了便於實作者快速理解，資料欄位會使用易於理解的命名，實作者再透過邏輯模型中的功能頁籤「Mappings」瞭解各資料欄位實際使用本IG的哪個Profiles的哪個資料項目（element）。
* [FHIR Profiles 及 Extensions](extension.md)： 
* TW xx IG 的所有 Profiles 之定義與範例及Extensions。
* 各資料項目不同實作強制程度的 Terminology
* 各資料項目的限制（Constraints）。
* 查詢依據 TW xx IG 實作之 FHIR Server 的特定 Profiles 時，可使用的查詢參數。
* 有哪些 Profiles 具有查詢參數以及 Server 必須支援哪些必要的查詢參數功能。
 
 
* [專門術語](terminology.md)：TW XX IG網站所使用的專門術語，包括代碼系統（Code Systems）及值集（Value Sets），內容主要依據全國專門術語服務平臺（TW terminology services）與長期照顧情境使用之術語建置。
* [範例](example.md)：TW XX IG 的所有範例。
* [結構定義與範例下載](download.md)：實作者若不偏好使用 FHIR RESTful API 驗證資料是否遵從 Profiles，可直接下載所需的格式驗證檔，包括 XML、JSON 及 Turtle 三種格式，亦可於此下載完整範例。
* [安全性](security.md)：主要說明採用 TW xx IG 網站進行實作時，有關資料存取授權的作法。

-------

## 作者與貢獻者

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| 作者 | v0.0.1 | 富伯生醫股份有限公司 | 黃嗣承 | 富伯生醫股份有限公司 |
| 作者 | v0.0.1 | 富伯生醫股份有限公司 | 高旭恩 | 富伯生醫股份有限公司 |
| 作者 | v0.0.1 | 富伯生醫股份有限公司 | 王世東 | 富伯生醫股份有限公司 |

