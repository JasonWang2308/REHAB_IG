# FHIR Profiles及Extensions - v0.1.0

* [**Table of Contents**](toc.md)
* [**範例**](example.md)
* **FHIR Profiles及Extensions**

## FHIR Profiles及Extensions

## Resources之Profiles

以下為XX 實作指引 (xx IG) 使用到的所有Profiles

### Patient

* [病人]

