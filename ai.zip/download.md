# 結構定義與範例檔下載 - v0.1.0

* [**Table of Contents**](toc.md)
* **結構定義與範例檔下載**

## 結構定義與範例檔下載

# 結構定義與範例檔下載 (Downloads)

本頁提供本實作指引 (**Example IG**) 的所有結構定義、值集 (ValueSet)、代碼系統 (CodeSystem)、
 以及範例資源 (Example Instances) 的下載連結，方便使用者離線瀏覽或驗證。

-------

