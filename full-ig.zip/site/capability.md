# 能力聲明 - v0.1.0

* [**Table of Contents**](toc.md)
* [**範例**](example.md)
* **能力聲明**

## 能力聲明

[用戶端](CapabilityStatement-MyFHIRClientCapabilityStatement.md)

[伺服端](CapabilityStatement-MyFHIRServerCapabilityStatement.md)

