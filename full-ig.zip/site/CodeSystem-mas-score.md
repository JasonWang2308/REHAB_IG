# CSMAS - v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **CSMAS**

## CodeSystem: CSMAS 

| | |
| :--- | :--- |
| *Official URL*:http://example.org/CodeSystem/mas-score | *Version*:0.1.0 |
| Draft as of 2025-10-28 | *Computable Name*:CSMAS |

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "mas-score",
  "url" : "http://example.org/CodeSystem/mas-score",
  "version" : "0.1.0",
  "name" : "CSMAS",
  "status" : "draft",
  "date" : "2025-10-28T11:34:57+08:00",
  "publisher" : "Example Publisher",
  "contact" : [
    {
      "name" : "Example Publisher",
      "telecom" : [
        {
          "system" : "url",
          "value" : "http://example.org/example-publisher"
        }
      ]
    }
  ],
  "content" : "complete",
  "count" : 6,
  "concept" : [
    {
      "code" : "0",
      "display" : "0: 肌張力沒有增加"
    },
    {
      "code" : "1",
      "display" : "1: 輕微增加肌張力，當受測的肢體在彎曲或伸展時，在活動範圍的最末段會呈現如卡住般 (catch)些微的張力"
    },
    {
      "code" : "1+",
      "display" : "1+: 輕微增加肌張力，當受測的肢體在彎曲或伸展時，會先呈現如卡住般些微的張力，並接 續著輕微的張力直到活動範圍結束，出現張力的比例小於50%的活動範圍"
    },
    {
      "code" : "2",
      "display" : "2: 大部分的活動範圍都呈現張力，但受影響的肢體是可以輕易活動的"
    },
    {
      "code" : "3",
      "display" : "3: 大部分的活動範圍都呈現大幅增加的張力，受影響的肢體的被動活動是困難的"
    },
    {
      "code" : "4",
      "display" : "4: 受影響的肢體在彎曲或伸展時是僵硬的"
    }
  ]
}

```
